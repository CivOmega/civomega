"""
Contains code that logs questions asked, answers received, and questions
for which we did not have an answer for.
"""
