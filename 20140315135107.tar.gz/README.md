# CivOmega

[![Build Status](https://travis-ci.org/CivOmega/civomega.png?branch=develop)](https://travis-ci.org/CivOmega/civomega)

This doc is TODO. But there's a *tiny* bit of developer-specific documentation
available. See [CONTRIBUTING.md](CONTRIBUTING.md) and the files in the
[doc directory](doc).

---

`civomega.data` represents Django models & functionality related to the
question-answering `Module`s, `DataSource`s, `QuestionPattern`s and the like.

`civomega.cologger` represents Django models & functionality related to
logging of user input, detecting whether answer-generation is taking too long,
etc.
